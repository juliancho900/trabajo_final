-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 25-04-2017 a las 23:02:59
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `cinema`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facturacion`
--

CREATE TABLE IF NOT EXISTS `facturacion` (
  `id_factura` int(30) NOT NULL AUTO_INCREMENT,
  `nombre_pelicula` varchar(30) NOT NULL,
  `nombre_cliente` varchar(30) NOT NULL,
  `cupos_pelicula` int(30) NOT NULL,
  `horario_venta` varchar(10) NOT NULL,
  `fecha_venta` varchar(30) NOT NULL,
  `valor_taquilla` int(30) NOT NULL,
  PRIMARY KEY (`id_factura`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `facturacion`
--

INSERT INTO `facturacion` (`id_factura`, `nombre_pelicula`, `nombre_cliente`, `cupos_pelicula`, `horario_venta`, `fecha_venta`, `valor_taquilla`) VALUES
(1, 'xmen', 'hola', 3, '18:53:05', '04/23/17', 10000),
(2, 'xmen', 'camilo', 5, '19:05:51', '04/23/17', 10000),
(3, 'xmen', 'lopez', 3, '19:08:59', '04/23/17', 10000),
(4, 'avatar', 'fausto', 3, '19:26:11', '04/23/17', 10000),
(5, 'xmen', 'lopez', 2, '20:16:39', '04/23/17', 20000),
(6, 'xmen', 'lopez', 3, '20:18:03', '04/23/17', 30000),
(7, 'avatar', 'marcela', 6, '20:37:52', '04/23/17', 60000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pelicula`
--

CREATE TABLE IF NOT EXISTS `pelicula` (
  `id_pelicula` int(20) NOT NULL AUTO_INCREMENT,
  `nom_pelicula` varchar(30) NOT NULL,
  `valor_taquilla` int(30) NOT NULL,
  `sillas_disponibles` int(30) NOT NULL,
  PRIMARY KEY (`id_pelicula`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `pelicula`
--

INSERT INTO `pelicula` (`id_pelicula`, `nom_pelicula`, `valor_taquilla`, `sillas_disponibles`) VALUES
(1, 'xmen', 10000, 5),
(4, 'matrix', 10000, 5),
(3, 'avatar', 10000, 5),
(5, 'matriz recargado', 15000, 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE IF NOT EXISTS `productos` (
  `id_producto` int(30) NOT NULL AUTO_INCREMENT,
  `nombre_producto` varchar(30) NOT NULL,
  `puntos_producto` int(30) NOT NULL,
  PRIMARY KEY (`id_producto`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `nombre_producto`, `puntos_producto`) VALUES
(1, 'crispetas', 500),
(2, 'gaseosa', 600);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntos`
--

CREATE TABLE IF NOT EXISTS `puntos` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `nombre_cliente` varchar(30) NOT NULL,
  `puntos_cliente` int(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcar la base de datos para la tabla `puntos`
--

INSERT INTO `puntos` (`id`, `nombre_cliente`, `puntos_cliente`) VALUES
(1, 'hola', 100),
(2, 'camilo', 100),
(3, 'lopez', 100),
(4, 'fausto', 100),
(5, 'lopez', 300),
(6, 'marcela', 600);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id_cedula` int(30) NOT NULL,
  `nombre_usuario` varchar(40) NOT NULL,
  `tipo_usuario` varchar(30) NOT NULL,
  `correo` varchar(30) NOT NULL,
  `contrasena` int(10) NOT NULL,
  `fecha_registro` varchar(15) NOT NULL,
  PRIMARY KEY (`id_cedula`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_cedula`, `nombre_usuario`, `tipo_usuario`, `correo`, `contrasena`, `fecha_registro`) VALUES
(1112773913, 'Julian', 'administrador', 'juliancho_900@hotmail.com', 12345, '24/04/17'),
(14572150, 'Fercho', 'usuario', 'guty-15@hotmail.com', 147, '24/04/17');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
